
"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Radio, ShieldCheck, Video, AlertCircle, Loader2, Camera } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { BottomNav } from "@/components/BottomNav"
import { moderateContentSafety, ModerateContentSafetyOutput } from "@/ai/flows/ai-moderate-content-safety"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const CATEGORY_MAP = {
  "bakra": {
    label: "Bakra (Goat)",
    subs: [
      { id: "khasi", label: "Khasi Bakra" },
      { id: "andu", label: "Andu Bakra" },
      { id: "desi-bakra", label: "Desi Bakra" },
      { id: "sirohi", label: "Sirohi" }
    ]
  },
  "murga": {
    label: "Murga (Chicken)",
    subs: [
      { id: "desi-murga", label: "Desi Murga" },
      { id: "broiler", label: "Broiler Chicken" },
      { id: "kadaknath", label: "Kadaknath" }
    ]
  },
  "fish": {
    label: "Machli (Fish)",
    subs: [
      { id: "rohu", label: "Rohu" },
      { id: "katla", label: "Katla" },
      { id: "surmai", label: "Surmai" }
    ]
  }
}

export default function GoLivePage() {
  const [isLive, setIsLive] = useState(false)
  const [step, setStep] = useState(1) // 1: Setup, 2: Streaming
  const [category, setCategory] = useState<string>("")
  const [subCategory, setSubCategory] = useState<string>("")
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null)
  const [moderationResult, setModerationResult] = useState<ModerateContentSafetyOutput | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { toast } = useToast()

  // Effect to attach stream to video element once it's rendered
  useEffect(() => {
    if (mediaStream && videoRef.current) {
      videoRef.current.srcObject = mediaStream;
    }
  }, [mediaStream, step]);

  const startStream = async () => {
    if (!category || !subCategory) {
      toast({
        variant: "destructive",
        title: "जानकारी अधूरी है",
        description: "कृपया कैटेगरी और वैरायटी चुनें।"
      })
      return
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: "environment",
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }, 
        audio: true 
      })
      
      setMediaStream(stream)
      setStep(2)
      setIsLive(true)
      
      toast({
        title: "आप लाइव हैं!",
        description: "आपका ब्रॉडकास्ट शुरू हो गया है।"
      })
    } catch (err) {
      console.error("Camera access error:", err)
      toast({
        variant: "destructive",
        title: "कैमरा एरर",
        description: "कैमरा एक्सेस नहीं किया जा सका। कृपया परमिशन चेक करें।"
      })
    }
  }

  const stopStream = () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop())
    }
    setMediaStream(null)
    setIsLive(false)
    setStep(1)
    setModerationResult(null)
  }

  const captureFrame = useCallback(() => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video.videoWidth === 0) return null;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL('image/jpeg', 0.6);
      }
    }
    return null;
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isLive) {
      interval = setInterval(async () => {
        const frame = captureFrame();
        if (frame) {
          setIsAnalyzing(true);
          try {
            const result = await moderateContentSafety({ photoDataUri: frame });
            setModerationResult(result);
            if (result.suggestedAction === 'BLOCK_STREAM') {
              toast({
                variant: "destructive",
                title: "स्ट्रीम ब्लॉक कर दी गई",
                description: "AI ने आपत्तिजनक सामग्री का पता लगाया है।"
              });
              stopStream();
            }
          } catch (e) {
            console.error("Moderation failed", e);
          } finally {
            setIsAnalyzing(false);
          }
        }
      }, 20000); // Analyze every 20 seconds
    }
    return () => clearInterval(interval);
  }, [isLive, captureFrame, toast]);

  const selectedCategoryData = category ? CATEGORY_MAP[category as keyof typeof CATEGORY_MAP] : null

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="p-4 border-b border-border flex justify-between items-center bg-card sticky top-0 z-50">
        <h1 className="text-xl font-black text-foreground uppercase italic tracking-tighter">Broadcast Studio</h1>
        {isLive && (
          <Badge className="animate-pulse flex gap-1 items-center px-3 py-1 bg-orange-500 text-white border-none">
            <div className="w-2 h-2 rounded-full bg-white" />
            LIVE
          </Badge>
        )}
      </div>

      <div className="p-4">
        {step === 1 ? (
          <div className="space-y-6 max-w-md mx-auto">
            <div className="bg-card p-6 rounded-3xl border border-border space-y-6 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-secondary rounded-2xl text-orange-500">
                  <Video className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-black uppercase leading-none">Stream Setup</h2>
                  <p className="text-xs text-muted-foreground mt-1">Configure your live marketplace</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Category</Label>
                  <Select onValueChange={(val) => { setCategory(val); setSubCategory(""); }}>
                    <SelectTrigger className="h-12 bg-secondary/50 border-none rounded-xl font-bold">
                      <SelectValue placeholder="Select Category" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(CATEGORY_MAP).map(([id, data]) => (
                        <SelectItem key={id} value={id} className="font-bold">{data.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {category && (
                  <div className="space-y-2">
                    <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Variety</Label>
                    <Select onValueChange={setSubCategory}>
                      <SelectTrigger className="h-12 bg-secondary/50 border-none rounded-xl font-bold">
                        <SelectValue placeholder="Select Variety" />
                      </SelectTrigger>
                      <SelectContent>
                        {selectedCategoryData?.subs.map((sub) => (
                          <SelectItem key={sub.id} value={sub.id} className="font-bold">{sub.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Price (₹/kg)</Label>
                  <Input type="number" placeholder="850" className="h-12 bg-secondary/50 border-none rounded-xl font-bold" />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Stock (kg)</Label>
                  <Input type="number" placeholder="20" className="h-12 bg-secondary/50 border-none rounded-xl font-bold" />
                </div>
              </div>
            </div>

            <Button 
              onClick={startStream}
              size="lg" 
              className="w-full h-16 text-lg font-black uppercase bg-foreground text-background hover:bg-foreground/90 rounded-2xl shadow-xl transition-all active:scale-95"
            >
              <Radio className="mr-2 h-5 w-5 animate-pulse" />
              Go Live Now
            </Button>
          </div>
        ) : (
          <div className="space-y-4 max-w-md mx-auto">
            <div className="relative aspect-[9/16] bg-black rounded-[2rem] overflow-hidden border-2 border-border shadow-2xl">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className="w-full h-full object-cover"
              />
              <canvas ref={canvasRef} className="hidden" />
              
              {/* Overlays */}
              <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
                <div className="flex flex-col gap-2">
                  <Badge className="bg-cyan-500/80 backdrop-blur-md flex items-center gap-1.5 px-3 py-1.5 border-none text-white rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span className="text-[10px] font-black uppercase tracking-wider">AI Guard Active</span>
                  </Badge>
                  {isAnalyzing && (
                    <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full w-fit">
                      <Loader2 className="w-3 h-3 text-white animate-spin" />
                      <span className="text-[9px] text-white font-bold uppercase">Analyzing Stream...</span>
                    </div>
                  )}
                  {moderationResult?.suggestedWarning && (
                    <Badge variant="destructive" className="animate-bounce flex items-center gap-1 px-3 py-1 border-none">
                      <AlertCircle className="w-3 h-3" />
                      <span className="text-[9px] font-black uppercase">{moderationResult.suggestedWarning}</span>
                    </Badge>
                  )}
                </div>
                
                <Badge className="bg-black/60 backdrop-blur-md border-white/10 rounded-full px-3 py-1 flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-ping" />
                  <span className="text-[10px] text-white font-bold">124 Watching</span>
                </Badge>
              </div>

              <div className="absolute bottom-6 left-6 right-6">
                <div className="bg-black/40 backdrop-blur-xl p-4 rounded-2xl border border-white/10">
                  <h3 className="text-white font-black text-lg uppercase italic leading-none">
                    {selectedCategoryData?.subs.find(s => s.id === subCategory)?.label || "Live Feed"}
                  </h3>
                  <p className="text-white/60 text-[10px] font-bold uppercase tracking-widest mt-1">Hygienic • Fresh Cut • Locally Raised</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="h-14 rounded-xl border-border bg-card font-black uppercase text-xs">
                <Camera className="w-4 h-4 mr-2" />
                Flip Camera
              </Button>
              <Button 
                variant="destructive" 
                className="h-14 rounded-xl font-black uppercase text-xs"
                onClick={stopStream}
              >
                End Stream
              </Button>
            </div>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  )
}
