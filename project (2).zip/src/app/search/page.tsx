"use client"

import { BottomNav } from "@/components/BottomNav"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search as SearchIcon, MapPin, SlidersHorizontal, ChevronRight } from "lucide-react"
import { useState } from "react"
import Image from "next/image"

const CATEGORIES = [
  { name: "Bakra (Goat)", count: 12, icon: "🥩" },
  { name: "Murga (Chicken)", count: 45, icon: "🍗" },
  { name: "Fish (Freshwater)", count: 8, icon: "🐟" },
  { name: "Beef/Buffalo", count: 15, icon: "🥩" },
]

export default function SearchPage() {
  const [radius, setRadius] = useState("5 KM")

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="p-4 bg-card border-b border-border sticky top-0 z-50">
        <div className="relative mb-4">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-5 w-5" />
          <Input 
            placeholder="Search nearby sellers or meat type..." 
            className="pl-10 h-12 rounded-xl bg-secondary/50 border-none focus-visible:ring-primary" 
          />
        </div>
        
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          <Button variant="outline" size="sm" className="rounded-full border-primary/20 text-primary whitespace-nowrap">
            <MapPin className="w-3 h-3 mr-1" />
            {radius}
          </Button>
          {["Live Now", "Highest Rated", "Cheapest", "Home Delivery"].map((filter) => (
            <Badge key={filter} variant="secondary" className="px-3 py-1 rounded-full whitespace-nowrap bg-secondary/50 text-muted-foreground border-none">
              {filter}
            </Badge>
          ))}
          <Button variant="ghost" size="sm" className="rounded-full p-2">
            <SlidersHorizontal className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-6">
        <section>
          <h2 className="text-xl font-black mb-4 uppercase tracking-wide">Browse Categories</h2>
          <div className="grid grid-cols-2 gap-3">
            {CATEGORIES.map((cat) => (
              <button key={cat.name} className="flex flex-col items-start p-4 bg-card border border-border rounded-2xl hover:border-primary/40 transition-all text-left group">
                <span className="text-3xl mb-2">{cat.icon}</span>
                <span className="font-bold group-hover:text-primary transition-colors">{cat.name}</span>
                <span className="text-xs text-muted-foreground">{cat.count} shops nearby</span>
              </button>
            ))}
          </div>
        </section>

        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-black uppercase tracking-wide">Top Rated Shops</h2>
            <Button variant="link" className="text-primary p-0 h-auto">View All</Button>
          </div>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-4 p-3 bg-card border border-border rounded-2xl items-center">
                <div className="relative w-16 h-16 rounded-xl overflow-hidden shrink-0">
                  <Image src={`https://picsum.photos/seed/shop${i}/150/150`} alt="Shop" fill className="object-cover" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">Al-Barakah Meat Center</h3>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1 text-primary">★ 4.9</span>
                    <span>•</span>
                    <span>1.5 KM</span>
                  </div>
                </div>
                <ChevronRight className="text-muted-foreground" />
              </div>
            ))}
          </div>
        </section>
      </div>

      <BottomNav />
    </div>
  )
}