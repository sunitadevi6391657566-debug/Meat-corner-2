"use client"

import { BottomNav } from "@/components/BottomNav"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { User, Settings, CreditCard, HelpCircle, LogOut, Store, BadgeCheck, FileText } from "lucide-react"

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-primary/10 p-8 flex flex-col items-center border-b border-primary/20">
        <div className="relative mb-4">
          <Avatar className="w-24 h-24 border-4 border-background shadow-2xl">
            <AvatarImage src="https://picsum.photos/seed/user1/200/200" />
            <AvatarFallback>JD</AvatarFallback>
          </Avatar>
          <div className="absolute bottom-0 right-0 bg-primary p-1.5 rounded-full border-2 border-background">
            <Settings className="w-4 h-4 text-white" />
          </div>
        </div>
        <h1 className="text-2xl font-black">John Doe</h1>
        <p className="text-muted-foreground text-sm">+91 98765 43210</p>
        <div className="flex gap-2 mt-4">
          <BadgeCheck className="w-5 h-5 text-primary" />
          <span className="text-xs font-bold text-primary uppercase tracking-tighter">Verified Customer</span>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Wallet Section */}
        <Card className="p-6 bg-primary border-none shadow-xl shadow-primary/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-3xl group-hover:bg-white/20 transition-all" />
          <div className="relative z-10 flex justify-between items-center text-white">
            <div>
              <p className="text-white/80 text-sm font-medium mb-1">MeatCorner Wallet</p>
              <h2 className="text-3xl font-black">₹1,240.00</h2>
            </div>
            <Button size="sm" className="bg-white text-primary hover:bg-white/90 rounded-full px-6 font-bold">Add Cash</Button>
          </div>
        </Card>

        {/* Seller Portal CTA */}
        <Card className="p-4 border-dashed border-2 border-primary/40 bg-primary/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary rounded-xl">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold">Become a Seller</h3>
              <p className="text-xs text-muted-foreground">Start your live stream shop today</p>
            </div>
          </div>
          <Button size="sm" variant="outline" className="rounded-lg border-primary text-primary font-bold">Register</Button>
        </Card>

        {/* Menu Items */}
        <div className="space-y-1">
          {[
            { icon: User, label: "My Profile", value: "Edit details" },
            { icon: CreditCard, label: "Payment Methods", value: "2 cards saved" },
            { icon: FileText, label: "Seller License", value: "Upload required" },
            { icon: HelpCircle, label: "Help & Support", value: "" },
            { icon: LogOut, label: "Log Out", value: "", color: "text-red-500" },
          ].map((item, idx) => {
            const Icon = item.icon
            return (
              <button 
                key={idx} 
                className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-all rounded-xl group"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg bg-secondary group-hover:bg-background ${item.color || 'text-foreground'}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className={`font-bold ${item.color || ''}`}>{item.label}</span>
                </div>
                <span className="text-xs text-muted-foreground">{item.value}</span>
              </button>
            )
          })}
        </div>
      </div>

      <BottomNav />
    </div>
  )
}