"use client"

import { BottomNav } from "@/components/BottomNav"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ClipboardList, Clock, CheckCircle2, Package } from "lucide-react"

const MOCK_ORDERS = [
  {
    id: "MC-9921",
    shop: "Fresh Chicken Hub",
    items: "1.5kg Broiler Chicken",
    status: "Processing",
    time: "20 mins ago",
    total: 360,
    icon: Clock,
    color: "text-orange-500"
  },
  {
    id: "MC-8842",
    shop: "Premium Goat Farm",
    items: "2kg Bakra Meat",
    status: "Completed",
    time: "Yesterday",
    total: 1700,
    icon: CheckCircle2,
    color: "text-green-500"
  }
]

export default function OrdersPage() {
  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="p-4 bg-card border-b border-border flex justify-between items-center sticky top-0 z-50">
        <h1 className="text-xl font-black text-primary uppercase">My Bookings</h1>
        <Button variant="ghost" size="icon"><ClipboardList className="w-6 h-6" /></Button>
      </div>

      <div className="p-4">
        <Tabs defaultValue="active" className="w-full">
          <TabsList className="w-full grid grid-cols-2 rounded-xl bg-secondary/50 h-12">
            <TabsTrigger value="active" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white font-bold">Active</TabsTrigger>
            <TabsTrigger value="history" className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white font-bold">History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="active" className="mt-6 space-y-4">
            {MOCK_ORDERS.filter(o => o.status === "Processing").map(order => (
              <OrderCard key={order.id} order={order} />
            ))}
          </TabsContent>

          <TabsContent value="history" className="mt-6 space-y-4">
            {MOCK_ORDERS.filter(o => o.status === "Completed").map(order => (
              <OrderCard key={order.id} order={order} />
            ))}
          </TabsContent>
        </Tabs>
      </div>

      <BottomNav />
    </div>
  )
}

function OrderCard({ order }: { order: any }) {
  const Icon = order.icon
  return (
    <div className="bg-card border border-border rounded-2xl p-4 shadow-sm hover:border-primary/20 transition-all">
      <div className="flex justify-between items-start mb-4">
        <div className="flex gap-3">
          <div className="p-3 bg-secondary rounded-xl">
            <Package className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-lg leading-none mb-1">{order.shop}</h3>
            <p className="text-xs text-muted-foreground">Order ID: {order.id}</p>
          </div>
        </div>
        <Badge variant="outline" className={`flex gap-1 items-center px-2 py-1 ${order.color} border-current/20`}>
          <Icon className="w-3 h-3" />
          {order.status}
        </Badge>
      </div>
      
      <div className="flex justify-between items-end">
        <div>
          <p className="text-sm font-medium mb-1">{order.items}</p>
          <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">{order.time}</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-muted-foreground">Total Payable</p>
          <p className="text-xl font-black text-primary">₹{order.total}</p>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-border flex gap-2">
        <Button size="sm" className="flex-1 rounded-lg font-bold bg-primary">Track Live</Button>
        <Button size="sm" variant="outline" className="flex-1 rounded-lg font-bold">Details</Button>
      </div>
    </div>
  )
}